package edu.montana.csci.csci468.eval;

public class BreakExeption extends RuntimeException{

}
