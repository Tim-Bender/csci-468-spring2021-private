package edu.montana.csci.csci468.eval;

public class ContinueException extends RuntimeException{

}
