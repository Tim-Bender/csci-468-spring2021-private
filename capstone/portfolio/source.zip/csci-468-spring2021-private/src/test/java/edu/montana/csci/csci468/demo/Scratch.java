package edu.montana.csci.csci468.demo;

public class Scratch {
    String s = "bacon";
    public void driver(){
        System.out.println(s);
    }

    public Object test(Object x, int y){
        return null;
    }
}
